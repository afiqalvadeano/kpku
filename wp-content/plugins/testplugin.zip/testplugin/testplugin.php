<?php
/*
Bismillahirrahmannirrahin 

Plugin Name: Plugin View Caldera Forms
Description: View Database Caldera Forms
Version: 1.1.3
Domain Path: /languages
*/

include('fungsi.php');
